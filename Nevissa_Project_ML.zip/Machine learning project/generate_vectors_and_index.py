import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

INPUT_CLEAN_JSON = Path("processed_abstracts.json")
OUTPUT_FINAL_JSON = Path("fsbm_final_dataset_with_embeddings.json")
OUTPUT_INDEX = Path("semantic_index.npz")
OUTPUT_METADATA = Path("embedding_metadata.json")

ZEMBED_MODEL_NAME = "zeroentropy/zembed-1-embedding"
FALLBACK_DIMENSION = 384


def l2_normalize(matrix: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return matrix / norms


def deterministic_embedding(text: str, dimension: int = FALLBACK_DIMENSION) -> np.ndarray:
    """Offline fallback for reproducible demos when zembed-1 is not installed."""
    vector = np.zeros(dimension, dtype=np.float32)
    tokens = (text or "").lower().split()
    if not tokens:
        return vector

    for token in tokens:
        digest = hashlib.sha256(token.encode("utf-8")).digest()
        index = int.from_bytes(digest[:4], "little") % dimension
        sign = 1.0 if digest[4] % 2 == 0 else -1.0
        vector[index] += sign

    norm = np.linalg.norm(vector)
    return vector / norm if norm else vector


def load_profiles(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def flatten_articles(profiles):
    records = []
    for profile in profiles:
        for article in profile.get("articles", []):
            records.append(
                {
                    "chercheur_id": profile.get("chercheur_id", ""),
                    "nom_complet": profile.get("nom_complet", ""),
                    "affiliation": profile.get("affiliation", ""),
                    "article_id": article.get("article_id", ""),
                    "titre": article.get("titre", ""),
                    "abstract_clean": article.get("abstract_clean", ""),
                    "citations": int(article.get("citations") or 0),
                    "date_publication": article.get("date_publication", ""),
                    "journal": article.get("journal", ""),
                }
            )
    return records


def encode_with_zembed(texts):
    from sentence_transformers import SentenceTransformer

    model = SentenceTransformer(ZEMBED_MODEL_NAME, trust_remote_code=True)
    embeddings = model.encode(
        texts,
        batch_size=16,
        show_progress_bar=True,
        normalize_embeddings=True,
    )
    return np.asarray(embeddings, dtype=np.float32)


def encode_texts(texts, prefer_zembed=True):
    if prefer_zembed:
        try:
            embeddings = encode_with_zembed(texts)
            return embeddings, ZEMBED_MODEL_NAME, "zembed-1"
        except Exception as exc:
            print(f"[!] zembed-1 unavailable, using deterministic local fallback: {exc}")

    embeddings = np.vstack([deterministic_embedding(text) for text in texts])
    return embeddings, "deterministic-hash-embedding", "offline-fallback"


def attach_embeddings(profiles, embeddings):
    cursor = 0
    for profile in profiles:
        for article in profile.get("articles", []):
            article["embedding_zembed1"] = embeddings[cursor].round(6).tolist()
            cursor += 1
    return profiles


def save_index(records, embeddings, model_name, model_status):
    np.savez_compressed(
        OUTPUT_INDEX,
        embeddings=embeddings.astype(np.float32),
        article_ids=np.array([row["article_id"] for row in records]),
    )
    OUTPUT_METADATA.write_text(
        json.dumps(
            {
                "model_name": model_name,
                "model_status": model_status,
                "index_file": str(OUTPUT_INDEX),
                "dataset_file": str(OUTPUT_FINAL_JSON),
                "embedding_field": "embedding_zembed1",
                "count": len(records),
                "dimension": int(embeddings.shape[1]) if len(records) else 0,
            },
            indent=2,
        ),
        encoding="utf-8",
    )


def vectorize_and_index(prefer_zembed=True):
    if not INPUT_CLEAN_JSON.exists():
        raise FileNotFoundError(f"Run cleaner.py first. Missing: {INPUT_CLEAN_JSON}")

    profiles = load_profiles(INPUT_CLEAN_JSON)
    records = flatten_articles(profiles)
    texts = [row["abstract_clean"] for row in records]
    print(f"[*] Encoding {len(texts)} cleaned abstracts...")

    embeddings, model_name, model_status = encode_texts(texts, prefer_zembed=prefer_zembed)
    embeddings = l2_normalize(embeddings)
    attach_embeddings(profiles, embeddings)

    OUTPUT_FINAL_JSON.write_text(
        json.dumps(profiles, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    save_index(records, embeddings, model_name, model_status)

    print(f"[+] Final dataset: {OUTPUT_FINAL_JSON}")
    print(f"[+] Vector index: {OUTPUT_INDEX}")
    print(f"[+] Model status: {model_status} ({model_name})")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--offline",
        action="store_true",
        help="Skip zembed-1 loading and build a deterministic local demo index.",
    )
    args = parser.parse_args()
    vectorize_and_index(prefer_zembed=not args.offline)
