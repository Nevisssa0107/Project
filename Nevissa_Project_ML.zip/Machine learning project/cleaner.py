import csv
import json
import re
from pathlib import Path

INPUT_RAW_FILE = Path("raw_scholar_data.json")
OUTPUT_CLEAN_JSON = Path("processed_abstracts.json")
OUTPUT_CLEAN_CSV = Path("processed_abstracts.csv")
OUTPUT_CLEAN_PARQUET = Path("processed_abstracts.parquet")


def clean_text(text: str) -> str:
    """Normalize an abstract while preserving useful scientific tokens."""
    if not text:
        return ""

    text = text.lower()
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)
    text = re.sub(r"[^a-z0-9\s.,;:()/%+\-'']", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def safe_year(value) -> str:
    value = str(value or "").strip()
    match = re.search(r"(19|20)\d{2}", value)
    return match.group(0) if match else value


def flatten_profiles(profiles):
    flat_records = []
    clean_profiles = []
    seen_articles = set()

    for profile in profiles:
        clean_articles = []
        metrics = profile.get("metriques", {}) or {}

        for article in profile.get("articles", []):
            raw_abstract = (article.get("abstract") or "").strip()
            if len(raw_abstract) < 20:
                continue

            article_id = article.get("article_id") or f"{profile.get('chercheur_id')}:{article.get('titre')}"
            if article_id in seen_articles:
                continue
            seen_articles.add(article_id)

            clean_article = {
                "article_id": article_id,
                "titre": article.get("titre", ""),
                "auteurs": article.get("auteurs", []),
                "date_publication": safe_year(article.get("date_publication", "")),
                "journal": article.get("journal", ""),
                "citations": int(article.get("citations") or 0),
                "pdf_url": article.get("pdf_url", ""),
                "abstract": raw_abstract,
                "abstract_clean": clean_text(raw_abstract),
            }
            clean_articles.append(clean_article)

            flat_records.append(
                {
                    "chercheur_id": profile.get("chercheur_id", ""),
                    "nom_complet": profile.get("nom_complet", ""),
                    "affiliation": profile.get("affiliation", ""),
                    "citations_totales": int(metrics.get("citations_totales") or 0),
                    "h_index": int(metrics.get("h_index") or 0),
                    "i10_index": int(metrics.get("i10_index") or 0),
                    "article_id": clean_article["article_id"],
                    "titre": clean_article["titre"],
                    "auteurs": "; ".join(clean_article["auteurs"]),
                    "date_publication": clean_article["date_publication"],
                    "journal": clean_article["journal"],
                    "citations": clean_article["citations"],
                    "pdf_url": clean_article["pdf_url"],
                    "abstract": clean_article["abstract"],
                    "abstract_clean": clean_article["abstract_clean"],
                }
            )

        if clean_articles:
            clean_profiles.append(
                {
                    "chercheur_id": profile.get("chercheur_id", ""),
                    "nom_complet": profile.get("nom_complet", ""),
                    "affiliation": profile.get("affiliation", ""),
                    "metriques": metrics,
                    "articles": clean_articles,
                }
            )

    return clean_profiles, flat_records


def write_csv(path: Path, records):
    if not records:
        path.write_text("", encoding="utf-8")
        return

    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(records[0].keys()))
        writer.writeheader()
        writer.writerows(records)


def write_parquet_if_available(path: Path, records):
    try:
        import pandas as pd

        pd.DataFrame(records).to_parquet(path, index=False)
        return True
    except Exception as exc:
        print(f"[!] Parquet skipped: {exc}")
        return False


def run_cleaning():
    print("[*] Starting data cleaning process...")
    raw_profiles = json.loads(INPUT_RAW_FILE.read_text(encoding="utf-8"))
    clean_profiles, flat_records = flatten_profiles(raw_profiles)

    OUTPUT_CLEAN_JSON.write_text(
        json.dumps(clean_profiles, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    write_csv(OUTPUT_CLEAN_CSV, flat_records)
    parquet_ok = write_parquet_if_available(OUTPUT_CLEAN_PARQUET, flat_records)

    print(f"[+] Cleaned profiles: {len(clean_profiles)}")
    print(f"[+] Cleaned articles: {len(flat_records)}")
    print(f"[+] JSON: {OUTPUT_CLEAN_JSON}")
    print(f"[+] CSV: {OUTPUT_CLEAN_CSV}")
    if parquet_ok:
        print(f"[+] Parquet: {OUTPUT_CLEAN_PARQUET}")


if __name__ == "__main__":
    run_cleaning()
