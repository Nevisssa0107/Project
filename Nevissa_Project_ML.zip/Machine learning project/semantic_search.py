import argparse
import json
from pathlib import Path

import numpy as np

from generate_vectors_and_index import deterministic_embedding

DATASET_FILE = Path("fsbm_final_dataset_with_embeddings.json")
INDEX_FILE = Path("semantic_index.npz")
METADATA_FILE = Path("embedding_metadata.json")


def load_articles():
    profiles = json.loads(DATASET_FILE.read_text(encoding="utf-8"))
    articles = []
    for profile in profiles:
        for article in profile.get("articles", []):
            articles.append(
                {
                    "chercheur_id": profile.get("chercheur_id", ""),
                    "nom_complet": profile.get("nom_complet", ""),
                    "affiliation": profile.get("affiliation", ""),
                    "article_id": article.get("article_id", ""),
                    "titre": article.get("titre", ""),
                    "abstract_clean": article.get("abstract_clean", ""),
                    "citations": article.get("citations", 0),
                    "date_publication": article.get("date_publication", ""),
                    "journal": article.get("journal", ""),
                }
            )
    return articles


def query_embedding(query: str, dimension: int) -> np.ndarray:
    metadata = json.loads(METADATA_FILE.read_text(encoding="utf-8"))
    if metadata.get("model_status") == "zembed-1":
        try:
            from sentence_transformers import SentenceTransformer

            model = SentenceTransformer(metadata["model_name"], trust_remote_code=True)
            vector = model.encode([query], normalize_embeddings=True)[0]
            return np.asarray(vector, dtype=np.float32)
        except Exception as exc:
            print(f"[!] zembed-1 query encoding failed, fallback used: {exc}")

    return deterministic_embedding(query, dimension=dimension)


def semantic_search(query: str, top_k: int = 5):
    if not DATASET_FILE.exists() or not INDEX_FILE.exists():
        raise FileNotFoundError("Run cleaner.py then generate_vectors_and_index.py first.")

    articles = load_articles()
    index = np.load(INDEX_FILE, allow_pickle=True)
    embeddings = index["embeddings"].astype(np.float32)
    query_vector = query_embedding(query, embeddings.shape[1])

    scores = embeddings @ query_vector
    order = np.argsort(scores)[::-1][:top_k]

    results = []
    for rank, idx in enumerate(order, start=1):
        item = dict(articles[int(idx)])
        item["rank"] = rank
        item["score"] = float(scores[int(idx)])
        results.append(item)
    return results


def print_results(results):
    for item in results:
        print(f"\n#{item['rank']} score={item['score']:.4f}")
        print(f"Title: {item['titre']}")
        print(f"Researcher: {item['nom_complet']}")
        print(f"Year: {item['date_publication']} | Citations: {item['citations']}")
        print(f"Journal: {item['journal']}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Semantic search over FSBM publications.")
    parser.add_argument("query", help="Search query, e.g. 'deep learning for medical imaging'")
    parser.add_argument("--top-k", type=int, default=5)
    args = parser.parse_args()
    print_results(semantic_search(args.query, top_k=args.top_k))
