# Rapport court - Cartographie Semantique FSBM

## 1. Contexte

Ce projet vise a construire un pipeline de donnees pour analyser la production scientifique des enseignants-chercheurs de la Faculte des Sciences Ben M'Sick. Les donnees proviennent de Google Scholar et sont structurees afin de permettre une recherche semantique sur les abstracts des publications.

## 2. Architecture du pipeline

### Etape 1 - Scraping

Le script `scraper.py` lit `input_faculty_list.json`, recupere les profils Google Scholar avec `scholarly`, extrait les metriques des chercheurs et les publications, puis sauvegarde progressivement les donnees dans `raw_scholar_data.json`.

Robustesse ajoutee :

- reprise depuis le fichier deja scrape ;
- sauvegarde apres chaque profil ;
- pauses aleatoires entre requetes ;
- gestion des erreurs par profil et par publication ;
- extraction de `pdf_url` lorsque disponible.

### Etape 2 - Nettoyage

Le script `cleaner.py` nettoie les abstracts, supprime les articles sans resume exploitable, normalise les dates et produit :

- `processed_abstracts.json` pour garder la structure chercheur -> articles ;
- `processed_abstracts.csv` pour l'analyse tabulaire ;
- `processed_abstracts.parquet` si `pyarrow` ou `fastparquet` est installe.

### Etape 3 - Embeddings et recherche semantique

Le script `generate_vectors_and_index.py` encode les abstracts nettoyes. Il tente d'abord d'utiliser le modele `zeroentropy/zembed-1-embedding`. Si l'environnement ne permet pas de telecharger ou charger le modele, il genere un fallback deterministe local afin de garder une demonstration executable.

Sorties :

- `fsbm_final_dataset_with_embeddings.json` avec le champ `embedding_zembed1` ;
- `semantic_index.npz` contenant la matrice d'embeddings normalisee ;
- `embedding_metadata.json` decrivant le modele utilise.

Le script `semantic_search.py` calcule la similarite cosinus entre une requete utilisateur et les publications indexees.

## 3. Dataset obtenu

L'extraction incluse contient un echantillon representatif de chercheurs FSBM. Apres nettoyage, le dataset conserve les articles ayant des abstracts exploitables et les champs suivants :

- identifiant chercheur ;
- nom complet ;
- affiliation ;
- metriques bibliometriques ;
- titre, auteurs, annee, journal, citations ;
- abstract brut ;
- abstract nettoye ;
- embedding `embedding_zembed1`.

## 4. Exemple d'utilisation

```bash
python cleaner.py
python generate_vectors_and_index.py
python semantic_search.py "deep learning for medical imaging" --top-k 5
```

Pour une demo hors-ligne :

```bash
python generate_vectors_and_index.py --offline
python semantic_search.py "machine learning cancer diagnosis" --top-k 5
```

## 5. Conclusion

Le projet couvre les livrables demandes : scraping, nettoyage, dataset final structure, vectorisation des abstracts et demonstration de recherche semantique. La version finale est reproductible et documente clairement le cas ou le modele `zembed-1` n'est pas disponible localement.
