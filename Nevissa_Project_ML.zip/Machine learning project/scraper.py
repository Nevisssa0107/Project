import json
import random
import time
from pathlib import Path

from scholarly import scholarly

INPUT_RESEARCHERS_FILE = Path("input_faculty_list.json")
OUTPUT_RAW_FILE = Path("raw_scholar_data.json")


def load_existing_profiles():
    if not OUTPUT_RAW_FILE.exists():
        return []
    try:
        return json.loads(OUTPUT_RAW_FILE.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []


def save_profiles(profiles):
    OUTPUT_RAW_FILE.write_text(
        json.dumps(profiles, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def polite_sleep(min_seconds=3.0, max_seconds=8.0):
    time.sleep(random.uniform(min_seconds, max_seconds))


def publication_to_article(scholar_id, pub_filled):
    bib = pub_filled.get("bib", {}) or {}
    return {
        "article_id": f"{scholar_id}:{pub_filled.get('author_pub_id', '')}",
        "titre": bib.get("title", ""),
        "auteurs": bib.get("author", "").split(" and ") if bib.get("author") else [],
        "date_publication": str(bib.get("pub_year", "")),
        "journal": bib.get("journal", bib.get("conference", "")),
        "citations": int(pub_filled.get("num_citations") or 0),
        "pdf_url": pub_filled.get("eprint_url", ""),
        "abstract": bib.get("abstract", ""),
    }


def scrape_one_profile(target, max_publications=None):
    scholar_id = target.get("chercheur_id")
    author_name = target.get("nom_complet")

    author = scholarly.search_author_id(scholar_id)
    author = scholarly.fill(author, sections=["basics", "indices", "publications"])

    profile_data = {
        "chercheur_id": scholar_id,
        "nom_complet": author.get("name", author_name),
        "affiliation": author.get("affiliation", ""),
        "metriques": {
            "citations_totales": int(author.get("citedby") or 0),
            "h_index": int(author.get("hindex") or 0),
            "i10_index": int(author.get("i10index") or 0),
        },
        "articles": [],
    }

    publications = author.get("publications", [])[:max_publications]
    for pub_index, pub in enumerate(publications, start=1):
        try:
            pub_filled = scholarly.fill(pub)
            profile_data["articles"].append(publication_to_article(scholar_id, pub_filled))
            print(f"    [+] publication {pub_index}/{len(publications)}")
            polite_sleep(1.5, 4.5)
        except Exception as pub_err:
            print(f"    [!] Skipping publication: {pub_err}")
            polite_sleep(4.0, 9.0)

    return profile_data


def scrape_profiles(max_publications=None):
    target_list = json.loads(INPUT_RESEARCHERS_FILE.read_text(encoding="utf-8"))
    scraped_data = load_existing_profiles()
    done_ids = {profile.get("chercheur_id") for profile in scraped_data}

    print(f"[*] Targets: {len(target_list)}")
    print(f"[*] Already scraped: {len(done_ids)}")

    for index, target in enumerate(target_list, start=1):
        scholar_id = target.get("chercheur_id")
        author_name = target.get("nom_complet")

        if scholar_id in done_ids:
            print(f"[{index}/{len(target_list)}] Skipping existing profile: {author_name}")
            continue

        print(f"[{index}/{len(target_list)}] Scraping: {author_name} ({scholar_id})")
        try:
            profile_data = scrape_one_profile(target, max_publications=max_publications)
            scraped_data.append(profile_data)
            done_ids.add(scholar_id)
            save_profiles(scraped_data)
            polite_sleep(5.0, 12.0)
        except Exception as exc:
            print(f"[!] Error processing {author_name}: {exc}")
            save_profiles(scraped_data)
            polite_sleep(20.0, 45.0)

    print(f"[+] Scraping complete. Saved to {OUTPUT_RAW_FILE}")


if __name__ == "__main__":
    scrape_profiles()
